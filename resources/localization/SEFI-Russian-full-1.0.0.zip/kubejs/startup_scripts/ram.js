StartupEvents.registry('item', event => {
    event.create('ram').displayName("Планка оперативной памяти на 1 ГБ")
    Platform.mods.kubejs.name = "Homestead Addons"
})