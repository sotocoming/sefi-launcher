StartupEvents.registry('item', event => {
    event.create('obsidian_upgrade_smithing_template').displayName("Кузнечный шаблон обсидианового улучшения")
    Platform.mods.kubejs.name = "Homestead Addons"
})