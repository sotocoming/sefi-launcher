StartupEvents.registry('item', event => {
    event.create('amd_drivers').displayName("Драйверы AMD")
    Platform.mods.kubejs.name = "Homestead Addons"
})