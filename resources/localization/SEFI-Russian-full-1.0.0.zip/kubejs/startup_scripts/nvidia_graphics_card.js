StartupEvents.registry('item', event => {
    event.create('nvidia_graphics_card').displayName("Видеокарта NVIDIA")
    Platform.mods.kubejs.name = "Homestead Addons"
})